﻿namespace POE_part_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Recipe recipe = new Recipe();

            //Declaration
            int ingredientCount;
            string ingredient;
            string unit;
            double quantity;
            int stepCount;
            string step;
            string input;

            //Inputs
            Console.Write("Enter number of ingredients: ");
            ingredientCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < ingredientCount; i++)
            {
                Console.Write("Enter ingredient name" + (i + 1) + ": ");
                ingredient = Console.ReadLine();
                Console.Write("Enter quantity of ingredient" + (i + 1) + ": ");
                quantity = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter measurement unit" + (i + 1) + ": ");
                unit = Console.ReadLine();

                //Method Call
                recipe.AddIngredient(ingredient, quantity, unit);
            }

            Console.Write("Enter number of steps: ");
            stepCount = int.Parse(Console.ReadLine());

            for (int i = 0;i < stepCount; i++)
            {
                Console.Write("Enter step" + (i + 1) + ": ");
                step = Console.ReadLine();
                recipe.AddStep(step);
            }

            Console.WriteLine("\nRecipe: ");
            Console.WriteLine();
            recipe.DisplayRecipe();

            Console.Write("\nEnter scaing factor (0.5,2, or 3) or 'reset' to reset quantities: ");
            input = Console.ReadLine();

            if (input == "reset")
            {
                recipe.ResetQuantities();
            }
            else if (double.TryParse(input, out double factor))
            {
                recipe.ScaleRecipe(factor);
            }

            Console.WriteLine("\nScaled recipe: ");
            Console.WriteLine(); //ADDED EPMTY LINE FOR EASY READING ON THE OUTPUT
            recipe.DisplayRecipe();

            Console.Write("\nEnter 'clear' to clear the recipe or any key to exit: ");
            input = Console.ReadLine();

            if (input == "clear")
            if (input == "CLEAR")
            if (input == "Clear")
            //user can input different forms of clear to avoid an error
            {
                recipe.ClearRecipe();
            }

            Console.ReadKey();
        }
    }
}
