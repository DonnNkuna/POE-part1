﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POE_part_1
{
    using System;
    public class Recipe
    {
        //Declaration
        private Ingredient[] ingredients;
        private string[] steps;

        //Constructor
        public Recipe()
        {
            ingredients = new Ingredient[0];
            steps = new string[0];
        }

        public void AddIngredient(string name, double quantity, string unit)
        {
            Array.Resize(ref ingredients, ingredients.Length + 1);
            ingredients[ingredients.Length - 1] = new Ingredient(name, quantity, unit);
        }

        public void AddStep(string step)
        {
            Array.Resize(ref steps, steps.Length + 1);
            steps[steps.Length - 1] = step;
        }
        //OUTPUT
        public void DisplayRecipe()
        {
            Console.WriteLine("Ingredients: ");

            foreach (Ingredient ingredient in ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
            }

            Console.WriteLine("\nSteps: ");
            for (int i = 0; i < steps.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {steps[i]}");
            }
        }

        public void ScaleRecipe(double factor)
        {
            for (int i = 0;i < ingredients.Length; i++)
            {
                ingredients[i].Quantity *= factor;
            }
        }

        public void ResetQuantities()
        {
            //reset quantities to original values if original values are stored seperately and accessible
            
        }

        public void ClearRecipe()
        {
            ingredients = new Ingredient[0];
            steps = new string[0];
        }
    }

    //struct class to store ingredient data
    public struct Ingredient
    {
        public string Name;
        public double Quantity;
        public string Unit;

        public Ingredient(string name, double quantity, string unit)
        {
            Name = name;
            Quantity = quantity;
            Unit = unit;
        }
    }
}
